<?php

namespace App\Http\Controllers;

use App\Models\Product;



class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $data=array();
        $getProducts=Product::orderBy('title','ASC')->get();
        $data['getProducts'] = $getProducts;
        return view('index', $data);

        // return view('index');
        
    }

    public function authenticator()
    {
        return view('authuser');
    }
    public function cart()
    {
        return view('cart');
    }

}
